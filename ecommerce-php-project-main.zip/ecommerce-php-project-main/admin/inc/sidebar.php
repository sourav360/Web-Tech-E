<div class="grid_2">
    <div class="box sidemenu">
        <div class="block" id="section-menu">
            <ul class="section menu">
                <li><a class="menuitem">Category Option</a>
                    <ul class="submenu">
                        <li><a href="catadd.php">Add Category</a></li>
                        <li><a href="catlist.php">Category List</a></li>
                    </ul>
                </li>
                <li><a class="menuitem">Product Option</a>
                    <ul class="submenu">
                        <li><a href="productadd.php">Add Product</a></li>
                        <li><a href="productlist.php">Product List</a></li>
                    </ul>
                </li>
                <li><a class="menuitem">Seller Option</a>
                    <ul class="submenu">
                        <li><a href="selleradd.php">Add Seller</a></li>
                        <li><a href="sellerlist.php">Seller List</a></li>
                    </ul>
                </li>
                <li><a class="menuitem">Order Option</a>
                    <ul class="submenu">
                        <li><a href="orderlist.php">Order List</a></li>
                    </ul>
                </li>
                <li><a class="menuitem">Delivery Boy Option</a>
                    <ul class="submenu">
                        <li><a href="deliveryboyadd.php">Add Delivery Boy</a></li>
                        <li><a href="deliveryboylist.php">Delivery Boy List</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</div>
